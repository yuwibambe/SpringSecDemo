package org.perscholas.entities;

public interface UserDetailsDao {
public abstract 	User findUserByUsername(String username);
}
